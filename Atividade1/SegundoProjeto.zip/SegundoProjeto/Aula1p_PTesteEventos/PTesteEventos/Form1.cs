﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteEventos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*
            // mascara
            mskbxSalario.Mask = "$9,999.99";
            // permitir valores numericos e decimais
            mskbxSalario.ValidatingType = 
                typeof(System.ComponentModel.DecimalConverter);
            mskbxSalario.PromptChar = ' ';
            mskbxSalario.TextAlign = HorizontalAlignment.Right;
            */
        }

        private void txtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            string Numeros = "0123456789";
            bool temNumero = Numeros.Contains(e.KeyChar);

            if (temNumero)
            {
                MessageBox.Show("nome não pode ter números");
                SendKeys.Send("{BACKSPACE}");
            }
        }

        private void txtEndereco_Validating(object sender, CancelEventArgs e)
        {
            if (txtEndereco.Text=="")
            {
                MessageBox.Show("Endereço inválido!");
                e.Cancel = true;
            }
        }

        private void txtEmail_Validated(object sender, EventArgs e)
        {
            if (txtEmail.Text=="")
            {
                MessageBox.Show("E-mail inválido!");
                txtEmail.Focus();
            }
        }

        private void mskbxData_Validated(object sender, EventArgs e)
        {
            DateTime dtNasc;

            if (!DateTime.TryParse(mskbxData.Text, out dtNasc))
            {
                MessageBox.Show("Data inválida!");
                mskbxData.Focus();
            }
            else
                MessageBox.Show("A data é: " + dtNasc.ToShortDateString());
        }

        private void mskbxVale_TextChanged(object sender, EventArgs e)
        {
            double vale;

            if (!Double.TryParse(mskbxVale.Text, out vale))
            {
                MessageBox.Show("Vale alimentação inválido!");
                mskbxVale.Focus();
            }
            else
                MessageBox.Show(vale.ToString());
        }



        

    private void mskbxSalario_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("Salário perde o foco");
        }

        private void button1_Enter(object sender, EventArgs e)
        {
            MessageBox.Show("Botão recebendo o foco");
        }

        
        private void txtCelular_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)13)//ENTER
            {
                SendKeys.Send("{TAB}");
                e.Handled = true; // desativar o beep
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dataNascimento;

            if (DateTime.TryParse(mskbxData.Text, out dataNascimento))
              MessageBox.Show($"Data ok: {dataNascimento.ToString("dd/MM/yyyy")}");
            else
              MessageBox.Show("Data inválida");

            double vale;
            if (double.TryParse(mskbxVale.Text,out vale))
            {
                MessageBox.Show("valor vale=" + vale.ToString("N2"));
                // MessageBox.Show($"valor vale={vale}");
            }
            else
                MessageBox.Show("o valor do vale é inválido");

        }
    }
}
