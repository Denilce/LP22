﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SegundoProjeto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox1.Items.Add("Sorocaba");
            listBox1.Items.Add("Votorantim");
            listBox1.Items.Add("Itu");
            listBox1.Items.Add("Piedade");
            listBox1.Items.Add("Ibiúna");
            listBox1.Items.Add("Pilar do Sul");
            listBox1.Sorted = true;
            listBox1.SelectedIndex = 0;


        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")  
                // if (textBox1.Text == String.Empty)
                //   if (textBox1.Text.Length == 0)
                MessageBox.Show("Nome vazio!");
            else
                MessageBox.Show("Nome Aluno: " + textBox1.Text);

            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Não escolheu turma");
            else
                MessageBox.Show($"Turma escolhida: {comboBox1.SelectedItem}");

            MessageBox.Show($"Cidade escolhida: {listBox1.SelectedItem}");

            //if (checkBox1.Checked)
            //    MessageBox.Show("Aluno veio transferido");
            //else
            //    MessageBox.Show("Aluno não veio transferido");

            if (checkBox1.CheckState==CheckState.Checked)
                MessageBox.Show("Aluno veio transferido");
            else if (checkBox1.CheckState==CheckState.Unchecked)
                MessageBox.Show("Aluno não veio transferido");
            else
                MessageBox.Show("Não informou se aluno veio transferido");

            if (radioButton1.Checked)
                MessageBox.Show("Tem aproveitamento de estudos");
            else
                MessageBox.Show("Não tem aproveitamento de estudos");

            //    for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
            //        MessageBox.Show($"Disciplina : {checkedListBox1.CheckedItems[i]}");

            string stringona = "";
            for (int i=0; i< checkedListBox1.CheckedItems.Count; i++)
                stringona += "\n" + checkedListBox1.CheckedItems[i].ToString();


            MessageBox.Show(stringona);

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Enter(object sender, EventArgs e)
        {

        }
    }
}
